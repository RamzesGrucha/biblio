from setuptools import setup

setup(
    name="wiktor",
    version='0.1',
    description='biblioteka',
    url='',
    author='wiktor zawadzki',
    author_email='wiktorr53@gmail.com',
    license='unlicense',
    packages=['projekty'],
    zip_safe=False
)